# BE ALTARED — DESIGN 001 MASTER RECORD

## Status
Finalized as the master development/IP record for Design 001.

This archive documents the development of the **BE ALTARED** T-shirt graphic. It is an internal authorship and asset record; it is **not itself a Copyright Office filing**.

## Work
- Title: BE ALTARED
- Design ID: 001
- Work type: 2-D graphic artwork / apparel artwork
- Intended use: Christian T-shirt graphic
- Brand: TBD; BE ALTARED is the saying/design title, not the brand
- Primary treatment: distressed monochrome clip-art / engraving / screen-print aesthetic
- Dark-shirt treatment: white/light monochrome
- Background: transparent alpha intended
- Central concept: an unidentified Old Testament-era figure kneeling humbly in prayer before a stone altar, listening rather than performing or celebrating.

## Final Creative Direction
- Large arched “BE ALTARED” typography
- Cross and divider lines
- Anonymous Old Testament-era worshipper viewed from behind
- Kneeling posture
- Humble/prayerful body language
- Head bowed
- Stone altar
- Stylized altar fire
- Biblical-era clothing
- Distressed clip-art / woodcut / engraved linework
- Broken ink and negative-space treatment for apparel printing
- No identified biblical character
- No modern church setting
- No additional saying or branding

## Development Record
The archive preserves the generated iterations used to develop the final direction, including:
1. Stone altar / prayer concept
2. Distressed monochrome treatment
3. Dark-shirt white-ink treatment
4. Modern church altar-call concept
5. Biblical patriarch/prophet concept
6. Kneeling, humble, listening posture
7. Rear-view anonymous figure
8. Refined clip-art / engraved treatment
9. Final dark-shirt-oriented development image

## AI-Assisted Development
Generative AI was used during concept and artwork development. The final copyright claim, if registered, should accurately distinguish AI-generated material from human-authored expression and should identify the human creative contributions and modifications actually made.

Do not represent this record as establishing that all pixels in an AI-assisted image are human-authored.

## Human Creative Direction Documented
The human-directed contributions reflected in this development include:
- Overall concept and message
- Selection of the altar/prayer subject
- Decision to use an unidentified Old Testament-era figure
- Rear-view composition
- Kneeling and humble/listening posture
- Altar, fire, clothing, and environmental direction
- Typography and phrase placement
- Cross placement
- Distressed clip-art / screen-print aesthetic
- Transparent/negative-space requirement
- Dark-shirt color treatment
- Iterative selection and refinement of the visual direction

The precise copyrightable scope should be determined from the final human-authored artwork and modifications actually incorporated.

## Registration Preparation
Before filing with the U.S. Copyright Office:
- Establish the final master artwork.
- Preserve the editable/source artwork and final export.
- Record completion date.
- Record first publication date when applicable.
- Record first sale/publication information when applicable.
- Prepare an accurate description of human-authored material and any material excluded because it was AI-generated.
- Use the Copyright Office's applicable visual-arts registration procedure.

## Asset Inventory
See `01_Artwork_Development/` for all preserved image iterations.
See `BE_ALTARED_Development_Contact_Sheet.png` for a visual index.

## Versioning Rule
Future designs should receive sequential IDs:
- Design 002
- Design 003
- Design 004
etc.

Each design should receive its own master record and development archive.
